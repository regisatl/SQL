-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 20 oct. 2022 à 16:30
-- Version du serveur :  5.7.31
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `learn`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `email` text NOT NULL,
  `tel` int(11) NOT NULL,
  `genre` varchar(255) NOT NULL,
  `annee` year(4) NOT NULL,
  `mdp` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`id`, `nom`, `prenom`, `email`, `tel`, `genre`, `annee`, `mdp`) VALUES
(1, 'ATTOLOU', 'Regis', 'regisattolou@outlook.fr', 68988452, 'Masculin', 2022, 'regis'),
(2, 'HOUESSOU', 'Espérance', 'esperancehouessou@gmail.com', 45123265, 'Féminin', 2022, '$2y$10$EdLH9lRl3/N//1QnZrSrJOpIRxZFBYETZx65E9xFgkZ5DBsUC.Eme'),
(3, 'ATTOLOU', 'Férenc', 'regisferenc16@gmail.com', 90919096, 'Masculin', 2022, '$2y$10$UfBbL6N9HALMQm22ReBiZOVj40z4oc2buZpeJEtYhFa5hIJrp9onW');

-- --------------------------------------------------------

--
-- Structure de la table `contact`
--

DROP TABLE IF EXISTS `contact`;
CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `email` text NOT NULL,
  `suggestions` text NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `contact`
--

INSERT INTO `contact` (`id`, `nom`, `email`, `suggestions`, `message`) VALUES
(1, 'ATTOLOU', 'regisattolou@outlook.fr', 'Il est là', 'Le dangereux');

-- --------------------------------------------------------

--
-- Structure de la table `inscription`
--

DROP TABLE IF EXISTS `inscription`;
CREATE TABLE IF NOT EXISTS `inscription` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `email` text NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `telephone` int(11) NOT NULL,
  `genre` varchar(255) NOT NULL,
  `date_naissance` varchar(255) NOT NULL,
  `demande` varchar(255) NOT NULL,
  `acte` varchar(255) NOT NULL,
  `diplome` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `module` varchar(255) NOT NULL,
  `annee` year(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `liste`
--

DROP TABLE IF EXISTS `liste`;
CREATE TABLE IF NOT EXISTS `liste` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `email` text NOT NULL,
  `telephone` int(11) NOT NULL,
  `groupe` int(11) NOT NULL,
  `genre` varchar(255) NOT NULL,
  `date_naissance` varchar(255) NOT NULL,
  `module` varchar(255) NOT NULL,
  `annee` varchar(255) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `mdp` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `liste`
--

INSERT INTO `liste` (`id`, `nom`, `prenom`, `email`, `telephone`, `groupe`, `genre`, `date_naissance`, `module`, `annee`, `adresse`, `mdp`) VALUES
(1, 'ATTOLOU', 'Regis', 'regisattolou21@outlook.fr', 68988452, 2, 'Masculin', '2000-06-21', 'Word', '2022', 'C/SB Tokan', '$2y$10$j6/RBhIgF3ZQ.f7/0mYnMO2e.K2VZNN7DJqG5odHOmdZxszMBcAgW'),
(2, 'HOUESSOU', 'Généviève', 'esperancehouessou@gmail.com', 45454545, 8, 'Féminin', '2004-01-03', 'Excel', '2022', 'C/SB Tokan', '$2y$10$jmeOfoGwJFgKsG5BdysAVebslXcRKCIkb7FDEdrlGKeekuPutctNa');

-- --------------------------------------------------------

--
-- Structure de la table `newsletter`
--

DROP TABLE IF EXISTS `newsletter`;
CREATE TABLE IF NOT EXISTS `newsletter` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `newsletter`
--

INSERT INTO `newsletter` (`id`, `email`) VALUES
(1, 'regisattolou@outlook.fr'),
(2, 'regisattolou@outlook.fr'),
(3, 'regisattolou@outlook.fr'),
(4, 'toto@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `notes`
--

DROP TABLE IF EXISTS `notes`;
CREATE TABLE IF NOT EXISTS `notes` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `idApprenant` int(11) NOT NULL,
  `devoir1` double NOT NULL,
  `devoir2` double NOT NULL,
  `devoir3` double NOT NULL,
  `examen` double NOT NULL,
  `module` varchar(255) NOT NULL,
  `groupe` int(4) NOT NULL,
  `annee` year(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `notes`
--

INSERT INTO `notes` (`id`, `idApprenant`, `devoir1`, `devoir2`, `devoir3`, `examen`, `module`, `groupe`, `annee`) VALUES
(1, 1, 12, 13, 15, 16, 'Word', 2, 2022),
(2, 2, 14, 12, 16, 10, 'Excel', 8, 2022);

-- --------------------------------------------------------

--
-- Structure de la table `programmes`
--

DROP TABLE IF EXISTS `programmes`;
CREATE TABLE IF NOT EXISTS `programmes` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `matieres` varchar(255) NOT NULL,
  `massesHoraires` varchar(4) NOT NULL,
  `coefficient` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `programmes`
--

INSERT INTO `programmes` (`id`, `matieres`, `massesHoraires`, `coefficient`) VALUES
(1, 'word', '20H', 5),
(2, 'Excel', '75H', 8);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
