-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 20 oct. 2022 à 16:30
-- Version du serveur :  5.7.31
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `examen`
--

-- --------------------------------------------------------

--
-- Structure de la table `candidat`
--

DROP TABLE IF EXISTS `candidat`;
CREATE TABLE IF NOT EXISTS `candidat` (
  `id_cand` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `datnais` varchar(100) NOT NULL,
  `ville` varchar(100) NOT NULL,
  `sexe` varchar(100) NOT NULL,
  `codfil` varchar(10) NOT NULL,
  PRIMARY KEY (`id_cand`),
  KEY `codfil` (`codfil`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `candidat`
--

INSERT INTO `candidat` (`id_cand`, `nom`, `prenom`, `datnais`, `ville`, `sexe`, `codfil`) VALUES
(1, 'ADIMI ', 'Jean', '10/0897', 'Cotonou', 'M', 'SIL'),
(2, 'SOGLO', 'Bernard', '12/09/94', 'Porto-Novo', 'M', 'RIT'),
(3, 'DOSSOU', 'Brice', '04/12/95', 'Cotonou', 'M', 'AGRO'),
(4, 'CHABI SIKI', 'Eric', '25/11/93', 'Parakou', 'M', 'SIL'),
(5, 'DOSSOU', 'Chantal', '18/02/94', 'Abomey', 'F', 'SIL'),
(6, 'ZINSSOU', 'Jules', '21/08/96', 'Ouidah', 'M', 'SIL'),
(7, 'ALAO', 'Mariam', '30/04/1996', 'Porto-Novo', 'F', 'AGE'),
(8, 'CHABI SIKA', 'Juliette', '10/05/1996', 'Bohicon', 'F', 'SIL'),
(9, 'Akpona', 'MoÃ¯se', '30/30/2000', 'Parakou', 'M', 'SIL'),
(10, 'KOTCHONI', 'PÃ©rin', '15/03/2001', 'SavÃ¨', 'M', 'RIT'),
(11, 'TCHATCHABLOUKOU', 'Josias', '18/05/99', 'Parakou', 'M', 'SIL'),
(12, 'Akpona', 'MoÃ¯se', '30/30/2000', 'Parakou', 'M', 'AGRO'),
(13, 'Akpona', 'MoÃ¯se', '30/30/2000', 'Parakou', 'M', 'AGRO'),
(14, 'Akpona', 'MoÃ¯se', '15/03/2001', 'Parakou', 'M', 'RIT'),
(15, 'Akpona', 'MoÃ¯se', '30/30/2000', 'Parakou', 'M', 'AGRO'),
(16, 'Akpona', 'MoÃ¯se', '30/30/2000', 'Parakou', 'M', 'AGRO');

-- --------------------------------------------------------

--
-- Structure de la table `filiere`
--

DROP TABLE IF EXISTS `filiere`;
CREATE TABLE IF NOT EXISTS `filiere` (
  `codefil` varchar(10) NOT NULL,
  `nomfil` varchar(255) NOT NULL,
  PRIMARY KEY (`codefil`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `filiere`
--

INSERT INTO `filiere` (`codefil`, `nomfil`) VALUES
('AGE', 'Administration et Gestion des Projets '),
('AGRO', 'Agronomie'),
('RIT', 'Réseaux Informatiques et Télécommunications'),
('SIL', 'Systèmes Informatiques et Logiciels');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `candidat`
--
ALTER TABLE `candidat`
  ADD CONSTRAINT `candidat_ibfk_1` FOREIGN KEY (`codfil`) REFERENCES `filiere` (`codefil`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
