-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 20 oct. 2022 à 16:28
-- Version du serveur :  5.7.31
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `essai`
--

-- --------------------------------------------------------

--
-- Structure de la table `candidat`
--

DROP TABLE IF EXISTS `candidat`;
CREATE TABLE IF NOT EXISTS `candidat` (
  `id_cand` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `datnais` varchar(255) NOT NULL,
  `ville` varchar(255) NOT NULL,
  `sexe` varchar(255) NOT NULL,
  `codfil` varchar(255) NOT NULL,
  PRIMARY KEY (`id_cand`),
  UNIQUE KEY `codfil` (`codfil`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `candidat`
--

INSERT INTO `candidat` (`id_cand`, `nom`, `prenom`, `datnais`, `ville`, `sexe`, `codfil`) VALUES
(1, 'ADIMI', 'Jean', '10/08/97', 'Cotonou', 'M', 'SIL'),
(2, 'SOGLO', 'Bernard', '12/02/94', 'Porto-Novo', 'M', 'RIT'),
(3, 'AMOUSSOU', 'Carolle', '18/06/2000', 'Cotonou', 'F', 'AGRO');

-- --------------------------------------------------------

--
-- Structure de la table `filiere`
--

DROP TABLE IF EXISTS `filiere`;
CREATE TABLE IF NOT EXISTS `filiere` (
  `codfil` varchar(10) NOT NULL,
  `nomfil` varchar(255) NOT NULL,
  PRIMARY KEY (`codfil`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `filiere`
--

INSERT INTO `filiere` (`codfil`, `nomfil`) VALUES
('AGE', 'Administration et gestion des entreprises'),
('AGRO', 'Agronomie'),
('RIT', 'Réseaux Informatiques et Télécommunications'),
('SIL', 'Systèmes Informatiques et Logiciels');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `candidat`
--
ALTER TABLE `candidat`
  ADD CONSTRAINT `candidat_ibfk_1` FOREIGN KEY (`codfil`) REFERENCES `filiere` (`codfil`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
